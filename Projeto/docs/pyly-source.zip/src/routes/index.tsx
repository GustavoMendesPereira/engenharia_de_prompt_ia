import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { SnakeBorder } from "@/components/SnakeBorder";
import { nextChallenge, type Challenge } from "@/lib/challenges";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Py.Ly — Desafios diários de lógica em Python" },
      { name: "description", content: "Py.Ly: jogo estilo Wordle/Termo com desafios infinitos de lógica em Python. Resolva, acerte e avance." },
    ],
  }),
  component: Index,
});

type Status = "idle" | "correct" | "wrong";

function Index() {
  // Current challenge (regenerated procedurally on each solve)
  const [challenge, setChallenge] = useState<Challenge>(() => nextChallenge());
  // Selected option index (or null)
  const [picked, setPicked] = useState<number | null>(null);
  // Visual status for feedback colors
  const [status, setStatus] = useState<Status>("idle");
  // Score counters
  const [streak, setStreak] = useState(0);
  const [solved, setSolved] = useState(0);
  const [misses, setMisses] = useState(0);

  // Auto-advance after a correct answer
  useEffect(() => {
    if (status !== "correct") return;
    const t = setTimeout(() => {
      setChallenge((prev) => nextChallenge(prev.code));
      setPicked(null);
      setStatus("idle");
    }, 850);
    return () => clearTimeout(t);
  }, [status]);

  // Reset wrong-state shake after a moment so the user can retry
  useEffect(() => {
    if (status !== "wrong") return;
    const t = setTimeout(() => setStatus("idle"), 600);
    return () => clearTimeout(t);
  }, [status]);

  const handlePick = (idx: number) => {
    if (status === "correct") return; // lock during transition
    setPicked(idx);
    if (challenge.choices[idx] === challenge.answer) {
      setStatus("correct");
      setStreak((s) => s + 1);
      setSolved((s) => s + 1);
    } else {
      setStatus("wrong");
      setStreak(0);
      setMisses((m) => m + 1);
    }
  };

  const skip = () => {
    setChallenge((prev) => nextChallenge(prev.code));
    setPicked(null);
    setStatus("idle");
    setStreak(0);
  };

  // Memoize block class per option for visual feedback
  const blockClass = useMemo(
    () => (idx: number) => {
      const base = "block w-full justify-start text-left cursor-pointer hover:border-accent transition-colors";
      if (picked !== idx) return base;
      if (status === "correct") return base + " block-correct";
      if (status === "wrong") return base + " block-wrong";
      return base;
    },
    [picked, status]
  );

  return (
    <main className="relative min-h-screen overflow-hidden">
      <SnakeBorder />

      <div className="relative z-10 mx-auto flex min-h-screen w-full max-w-2xl flex-col px-6 py-10 sm:py-14">
        {/* Header */}
        <header className="mb-8 flex items-center justify-between">
          <h1 className="text-3xl font-bold tracking-tight sm:text-4xl">
            Py<span className="text-[color:var(--accent)]">.</span>Ly
          </h1>
          <div className="flex gap-2 text-xs sm:text-sm">
            <span className="block">🔥 {streak}</span>
            <span className="block block-correct">✓ {solved}</span>
            <span className="block block-wrong">✗ {misses}</span>
          </div>
        </header>

        <p className="mb-6 text-sm text-[color:var(--muted-foreground)]">
          Resolva o desafio de Python. Acerte para avançar — desafios infinitos, gerados na hora.
        </p>

        {/* Challenge card */}
        <section
          key={challenge.code}
          className="mb-6 rounded-md border bg-[color:var(--muted)]/40 p-5 backdrop-blur-sm"
          style={{ animation: "pop 0.3s ease-out" }}
        >
          <div className="mb-2 text-xs uppercase tracking-widest text-[color:var(--muted-foreground)]">
            {challenge.hint}
          </div>
          <p className="mb-4 text-base sm:text-lg">{challenge.prompt}</p>
          <pre className="overflow-x-auto rounded bg-black/40 p-4 text-sm leading-relaxed">
            <code>{challenge.code}</code>
          </pre>
        </section>

        {/* Choices as Wordle-style blocks */}
        <div className="grid gap-3 sm:grid-cols-2">
          {challenge.choices.map((c, i) => (
            <button
              key={i + c}
              onClick={() => handlePick(i)}
              className={blockClass(i)}
              disabled={status === "correct"}
            >
              <span className="mr-3 text-[color:var(--muted-foreground)]">{String.fromCharCode(65 + i)}.</span>
              <code className="truncate">{c}</code>
            </button>
          ))}
        </div>

        {/* Footer actions */}
        <div className="mt-auto pt-10 flex items-center justify-between text-xs text-[color:var(--muted-foreground)]">
          <button onClick={skip} className="underline-offset-4 hover:underline">
            pular desafio →
          </button>
          <span>verde = correto · vermelho = errado</span>
        </div>
      </div>
    </main>
  );
}
